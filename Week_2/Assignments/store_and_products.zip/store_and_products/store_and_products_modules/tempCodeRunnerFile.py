women_purses.update_price(10,False)
