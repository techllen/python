x = md.subtract(1,3)
# x = md.subtract(2,3,4,5,6)