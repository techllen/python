print(locals())

# print(__name__)